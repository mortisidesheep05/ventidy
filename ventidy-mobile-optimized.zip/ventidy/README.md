# Ventidy — Complaint Management Platform

A modern, responsive React front end for Ventidy, built with React, React Router,
Tailwind CSS, Framer Motion, Chart.js, and React Hook Form. The project is
structured to plug straight into a Node.js/Express + MySQL REST API.

## Getting started

```bash
npm install
cp .env.example .env   # point VITE_API_BASE_URL at your backend
npm run dev
```

Build for production:

```bash
npm run build
npm run preview
```

## Project structure

```
src/
  components/   Reusable UI (layout, home sections, dashboard widgets, ui primitives)
  pages/        Route-level pages (Home, About, Services, Login, admin/*, ...)
  layouts/      MainLayout (public site) and AdminLayout (dashboard shell)
  context/      AuthContext (session) and ThemeContext (dark mode)
  services/     Axios-based API modules — one per resource (auth, complaints, users)
  hooks/        useFetch — generic async data-fetching hook
  utils/        Shared constants and formatting helpers
```

## Connecting the backend

Every network call goes through `src/services/apiClient.js`, an Axios instance
that reads its base URL from `VITE_API_BASE_URL` and attaches a bearer token
from `localStorage` automatically. Nothing in the UI is hardcoded — pages
render loading skeletons while requests are in flight and show explicit
empty/error states if the API is unreachable.

Expected REST endpoints (adjust paths in the service files if your API differs):

| Resource   | Endpoints |
|------------|-----------|
| Auth       | `POST /auth/login`, `POST /auth/register`, `POST /auth/forgot-password`, `POST /auth/logout`, `GET /auth/me` |
| Complaints | `POST /complaints` (multipart, incl. image), `GET /complaints/track`, `GET /complaints`, `PATCH /complaints/:id/status`, `PATCH /complaints/:id/assign`, `DELETE /complaints/:id`, `GET /complaints/stats` |
| Users      | `GET /users`, `GET /users/:id`, `PUT /users/:id`, `DELETE /users/:id` |
| Contact    | `POST /contact` |

A `user` object returned from `/auth/login` is expected to include a `role`
field (`"admin"` or `"user"`) — the admin dashboard route is protected and
only renders for `role === "admin"`.

## Design system

- **Palette:** navy `#0B1E3D`, brand blue `#2563EB`, sky `#38BDF8`, ice `#F8FAFC`, teal `#10B981`.
- **Type:** Space Grotesk (display), Inter (body), IBM Plex Mono (complaint IDs, data).
- **Signature element:** the "resolution ring" — a circular progress motif used in the
  hero, stats, and complaint-tracking page to visualize closing the loop on a complaint.
- **Dark mode:** class-based (`dark:`), toggled via `ThemeContext`, persisted to `localStorage`.

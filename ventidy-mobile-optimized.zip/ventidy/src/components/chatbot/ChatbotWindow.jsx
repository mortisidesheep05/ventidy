import ChatMessage from "./ChatMessage";
import ChatbotInput from "./ChatbotInput";
import { X, Bot } from "lucide-react";

export default function ChatbotWindow({
  messages,
  input,
  setInput,
  onSend,
  onClose,
}) {
  return (
    <div
      className="
        chatbot-window
        fixed
        bottom-24
        right-5
        z-50
        flex
        h-[500px]
        w-[360px]
        max-w-[calc(100vw-30px)]
        flex-col
        overflow-hidden
        rounded-2xl
        border
        border-gray-200
        bg-white
        shadow-2xl
        dark:border-navy-700
        dark:bg-navy-950
      "
    >

      {/* Header */}
      <div
        className="
          flex
          items-center
          justify-between
          bg-navy-900
          px-4
          py-3
          text-white
          dark:bg-white
          dark:text-navy-900
        "
      >
        <div className="flex items-center gap-3">

          <div
            className="
              flex
              h-9
              w-9
              items-center
              justify-center
              rounded-full
              bg-white/10
              dark:bg-navy-900/10
            "
          >
            <Bot size={20} />
          </div>

          <div>
            <h3 className="text-sm font-semibold">
              Ventidy AI
            </h3>

            <p className="text-xs opacity-70">
              How can I help?
            </p>
          </div>

        </div>

        <button
          onClick={onClose}
          className="
            rounded-full
            p-1.5
            transition
            hover:bg-white/10
            dark:hover:bg-navy-900/10
          "
        >
          <X size={20} />
        </button>
      </div>


      {/* Messages */}
      <div
        className="
          flex-1
          space-y-3
          overflow-y-auto
          bg-white
          p-4
          dark:bg-navy-950
        "
      >
        {messages.map((message, index) => (
          <ChatMessage
            key={index}
            message={message}
          />
        ))}
      </div>


      {/* Input */}
      <ChatbotInput
        input={input}
        setInput={setInput}
        onSend={onSend}
      />

    </div>
  );
}
import { Send } from "lucide-react";

export default function ChatbotInput({
  input,
  setInput,
  onSend,
}) {
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!input.trim()) return;

    onSend();
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="
        flex
        items-center
        gap-2
        border-t
        border-gray-200
        p-3
        dark:border-navy-700
      "
    >
      <input
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Ask something..."
        className="
          min-w-0
          flex-1
          rounded-xl
          border
          border-gray-200
          bg-gray-50
          px-3
          py-2.5
          text-sm
          text-gray-900
          outline-none
          focus:border-navy-900
          dark:border-navy-700
          dark:bg-navy-800
          dark:text-white
        "
      />

      <button
        type="submit"
        className="
          flex
          h-10
          w-10
          shrink-0
          items-center
          justify-center
          rounded-xl
          bg-navy-900
          text-white
          transition
          hover:opacity-90
          dark:bg-white
          dark:text-navy-900
        "
      >
        <Send size={18} />
      </button>
    </form>
  );
}
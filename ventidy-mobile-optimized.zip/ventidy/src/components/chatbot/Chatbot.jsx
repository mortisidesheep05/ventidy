import { useState } from "react";
import ChatbotButton from "./ChatbotButton";
import ChatbotWindow from "./ChatbotWindow";

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);

  const [input, setInput] = useState("");

  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content:
        "Hi! 👋 I'm Ventidy AI. How can I help you today?",
    },
  ]);

  const handleSend = () => {
    const userMessage = input.trim();

    if (!userMessage) return;

    // Add user message
    setMessages((prev) => [
      ...prev,
      {
        role: "user",
        content: userMessage,
      },
    ]);

    setInput("");

    // Temporary frontend-only response
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            "Thanks for your message!",
        },
      ]);
    }, 600);
  };

  return (
    <>
      {isOpen && (
        <ChatbotWindow
          messages={messages}
          input={input}
          setInput={setInput}
          onSend={handleSend}
          onClose={() => setIsOpen(false)}
        />
      )}

      <ChatbotButton
        isOpen={isOpen}
        onClick={() => setIsOpen((prev) => !prev)}
      />
    </>
  );
}
export default function ChatMessage({ message }) {
  const isUser = message.role === "user";

  return (
    <div
      className={`flex ${
        isUser ? "justify-end" : "justify-start"
      }`}
    >
      <div
        className={`
          max-w-[80%]
          rounded-2xl
          px-4
          py-2.5
          text-sm
          leading-relaxed
          ${
            isUser
              ? "rounded-br-md bg-navy-900 text-white dark:bg-white dark:text-navy-900"
              : "rounded-bl-md bg-gray-100 text-gray-800 dark:bg-navy-800 dark:text-gray-100"
          }
        `}
      >
        {message.content}
      </div>
    </div>
  );
}